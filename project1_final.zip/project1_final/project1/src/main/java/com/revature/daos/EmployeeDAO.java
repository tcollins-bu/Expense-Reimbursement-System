package com.revature.daos;

import java.util.List;

import com.revature.entities.Employee;

public interface EmployeeDAO {
	Employee addEmployee(Employee employee);

	Employee findById(int eid);

	List<Employee> findAll();

	Employee saveEmployee(Employee employee);

	boolean deleteEmployee(Employee employee);

}
