package com.revature.app;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.revature.controllers.EmployeeController;
import com.revature.controllers.ExpenseCategoryController;
import com.revature.controllers.ManagerController;
import com.revature.controllers.ReimbursementController;

import io.javalin.Javalin;

public class App {

	public static void main(String[] args) {
		
		Logger log = LoggerFactory.getLogger(App.class);
		log.info("App is Starting here"); 
		
		Javalin app = Javalin.create(config -> {
			config.enableCorsForAllOrigins();
			config.addStaticFiles("/public");
		}).start(7000);

//		########################
//		EMPLOYEE
// 		########################
		app.put("/employee", EmployeeController.addEmployee);

		app.get("/employees", EmployeeController.findAll);
		app.get("/employee/:eid", EmployeeController.findById);

		app.post("/employee", EmployeeController.saveEmployee);
		app.delete("/employee", EmployeeController.deleteEmployee);
//		########################
//		EXPENSE_CATEGORY
// 		########################
		app.put("/expense-category", ExpenseCategoryController.createExpenseCategory);

		app.get("/expense-categories", ExpenseCategoryController.getAllExpenseCategories);
		app.get("/expense-category/:cid", ExpenseCategoryController.getExpenseCategoryById);

		app.post("/expense-category", ExpenseCategoryController.updateExpenseCategory);
		app.delete("/expense-category", ExpenseCategoryController.deleteExpenseCategory);
//		########################
//		MANAGERS
// 		########################
		app.put("/manager", ManagerController.createManager);

		app.get("/managers", ManagerController.getAllManagers);
		app.get("/manager/:mid", ManagerController.getManagerById);

		app.post("/manager", ManagerController.updateManager);
		app.delete("/manager", ManagerController.deleteManager);
//		########################
//		REIMBURSEMENT
// 		########################
		app.put("/reimbursement", ReimbursementController.createReimbursement);

		app.get("/reimbursements", ReimbursementController.getAllReimbursements);
		app.get("/reimbursement/:rid", ReimbursementController.getReimbursementById);

		app.post("/reimbursement", ReimbursementController.saveReimbursement);
		app.delete("/reimbursement", ReimbursementController.deleteReimbursement);
		
		log.info("App is Ending here");

	}

}
