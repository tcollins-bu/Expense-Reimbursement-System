package com.revature.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.inject.Inject;

import com.revature.daos.EmployeeDAO;
import com.revature.daos.EmployeeDAOImp;
import com.revature.entities.Employee;

public class EmployeeServiceImp implements EmployeeService {

	private static EmployeeService eserv = null;

	@Inject
//	private EmployeeDAO edao;
	private static EmployeeDAO edao = EmployeeDAOImp.getEdao();

	private EmployeeServiceImp() {
		super();
	}

	public static EmployeeService getEserv() {
		if (eserv == null)
			eserv = new EmployeeServiceImp();

		return eserv;
	};

	@Override
	public Employee addEmployee(Employee employee) {
		return edao.addEmployee(employee);
	}

	@Override
	public Employee findById(int eid) {
		return edao.findById(eid);
	}

	@Override
	public Employee getEmployeeByEmail(String email) {

		List<Employee> employees = edao.findAll();
		for (Employee e : employees) {
			if (e.getEmail().compareToIgnoreCase(email) == 0)
				return e;
		}

		return null;
	}

	@Override
	public Employee getEmployeeByName(String name) {
		List<Employee> employees = edao.findAll();
		for (Employee e : employees) {
			if (e.getName().compareToIgnoreCase(name) == 0)
				return e;
		}

		return null;
	}

	@Override
	public List<Employee> getEmployeeByManager(int mgid) {
		List<Employee> employees = edao.findAll();
		List<Employee> managedByMgid = new ArrayList<Employee>();

		for (Employee e : employees) {
			if (e.getMgid() == mgid)
				managedByMgid.add(e);
		}

		return managedByMgid;
	}

	@Override
	public List<Employee> findAll() {
		return edao.findAll();
	}

	@Override
	public List<Employee> findAllNameAtoZ() {
		List<Employee> employees = edao.findAll();
		Collections.sort(employees, (e1, e2) -> String.CASE_INSENSITIVE_ORDER.compare(e1.getName(), e2.getName()));
		return employees;
	}

	@Override
	public List<Employee> findAllNameZtoA() {
		List<Employee> employees = edao.findAll();

		Collections.sort(employees, (e1, e2) -> String.CASE_INSENSITIVE_ORDER.compare(e1.getName(), e2.getName()));
		Collections.reverse(employees);
		return employees;
	}

	@Override
	public Employee saveEmployee(Employee employee) {
		return edao.saveEmployee(employee);
	}

	@Override
	public boolean deleteEmployee(Employee employee) {
		return edao.deleteEmployee(employee);
	}

}
