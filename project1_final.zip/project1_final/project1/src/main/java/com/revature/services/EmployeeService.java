package com.revature.services;

import java.util.List;

import com.revature.entities.Employee;

public interface EmployeeService {
//	CREATE
	Employee addEmployee(Employee employee);

//	READ
	Employee findById(int eid);

	Employee getEmployeeByEmail(String email);

	Employee getEmployeeByName(String name);

	List<Employee> getEmployeeByManager(int mgid);

	List<Employee> findAll();

	List<Employee> findAllNameAtoZ();

	List<Employee> findAllNameZtoA();

//	UPDATE
	Employee saveEmployee(Employee employee);

//	DELETE
	boolean deleteEmployee(Employee employee);

}
