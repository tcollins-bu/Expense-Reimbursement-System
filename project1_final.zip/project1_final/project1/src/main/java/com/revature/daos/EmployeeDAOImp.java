package com.revature.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.revature.entities.Employee;
import com.revature.utils.ConnectionUtil;

public class EmployeeDAOImp implements EmployeeDAO {
	private static EmployeeDAO edao;

	private EmployeeDAOImp() {
		super();
	}

	public static EmployeeDAO getEdao() {

		if (edao == null)
			edao = new EmployeeDAOImp();

		return edao;
	}

	@Override
	public Employee addEmployee(Employee employee) {
		try (Connection conn = ConnectionUtil.getConnection()) {
			String sql = "INSERT INTO employees VALUES (?,?,?,?,?,?)";
			PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			ps.setInt(1, 8);
			ps.setString(2, employee.getEmail());
			ps.setString(3, employee.getPassword());
			ps.setString(4, employee.getName());
			ps.setString(5, employee.getImage_url());
			ps.setInt(6, employee.getMgid());
			ps.execute();

			ResultSet rs = ps.getGeneratedKeys();
			rs.next();
			int key = rs.getInt("eid");
			employee.setEid(key);

			return employee;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Employee findById(int eid) {
		try (Connection conn = ConnectionUtil.getConnection()) {
			String sql = "SELECT * FROM employees WHERE eid = ?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, eid);

			ResultSet rs = ps.executeQuery();
			rs.next();

			Employee employee = new Employee();
			employee.setEmail(rs.getString("email"));
			employee.setPassword(rs.getString("password"));
			employee.setName(rs.getString("name"));
			employee.setImage_url(rs.getString("image_url"));
			employee.setMgid(rs.getInt("mgid"));
			employee.setEid(rs.getInt("eid"));

			return employee;

		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<Employee> findAll() {
		try (Connection conn = ConnectionUtil.getConnection()) {
			String sql = "SELECT * FROM employees";
			PreparedStatement ps = conn.prepareStatement(sql);

			ResultSet rs = ps.executeQuery();
			List<Employee> employees = new ArrayList<Employee>();
			Employee employee;
			while (rs.next()) {
				employee = new Employee();
				employee.setEmail(rs.getString("email"));
				employee.setPassword(rs.getString("password"));
				employee.setName(rs.getString("name"));
				employee.setImage_url(rs.getString("image_url"));
				employee.setMgid(rs.getInt("mgid"));
				employee.setEid(rs.getInt("eid"));

				employees.add(employee);
			}

			return employees;

		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public Employee saveEmployee(Employee employee) {
		try (Connection conn = ConnectionUtil.getConnection()) {
			String sql = "UPDATE EMPLOYEES SET email=?,password=?,name=?,image_url=?,mgid=? WHERE eid = ?";
			PreparedStatement ps = conn.prepareStatement(sql);

			ps.setString(1, employee.getEmail());
			ps.setString(2, employee.getPassword());
			ps.setString(3, employee.getName());
			ps.setString(4, employee.getImage_url());
			ps.setInt(5, employee.getMgid());
			ps.setInt(6, employee.getEid());

			if (ps.executeUpdate() > 0) {
				return employee;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean deleteEmployee(Employee employee) {
		try (Connection conn = ConnectionUtil.getConnection()) {
			String sql = "DELETE FROM employees WHERE eid = ?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, employee.getEid());

			if (ps.executeUpdate() > 0) {
				return true;
			}

			return false;

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}

	}

}
