package com.revature.servicetests;


import com.revature.entities.Employee;
import org.junit.jupiter.api.*;

import com.revature.services.EmployeeService;
import com.revature.services.EmployeeServiceImp;

import java.util.List;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class EmployeeServiceTest {

	private static EmployeeService eserv = EmployeeServiceImp.getEserv();

	@Test
	@Order(1)
	void addEmployee()
	{
		Employee e = new Employee(0,
				"one@email.com",
				"testPass",
				"one",
				"testImg.png",
				7);

		Employee result = eserv.addEmployee(e);

		Assertions.assertNotEquals(0, result.getEid());
	}

	@Test
	@Order(2)
	void findById()
	{
		Employee result = eserv.findById(10);

		Assertions.assertEquals(10,result.getEid() );
	}

	@Test
	@Order(3)
	void getEmployeeByEmail()
	{
		Employee result = eserv.getEmployeeByEmail("one@email.com");

		Assertions.assertEquals("one@email.com", result.getEmail());
	}

	@Test
	@Order(4)
	void getEmployeeByName()
	{
		Employee result = eserv.getEmployeeByName("one");

		Assertions.assertEquals("one", result.getName());
	}

	@Test
	@Order(5)
	void findAll()
	{
		List<Employee> employees = eserv.findAll();

		Assertions.assertNotEquals(0, employees.size());
	}

	@Test
	@Order(6)
	void findAllNameAtoZ()
	{
		List<Employee> employees = eserv.findAllNameAtoZ();

		Assertions.assertNotEquals(0, employees.size());
	}

	@Test
	@Order(7)
	void findAllNameZtoA()
	{
		List<Employee> employees = eserv.findAllNameZtoA();

		Assertions.assertNotEquals(0, employees.size());
	}

	@Test
	@Order(8)
	void saveEmployee()
	{
		List<Employee> employees = eserv.findAll();
		Employee updateMe = employees.get(employees.size()-1);
		updateMe.setName("Anthony Tony");
		Employee result = eserv.saveEmployee(updateMe);

		Assertions.assertEquals("Anthony Tony", result.getName());
	}

	@Test
	@Order(9)
	void deleteEmployee()
	{

		List<Employee> employees = eserv.findAll();
		Employee deleteMe = employees.get(employees.size()-1);
		boolean result = eserv.deleteEmployee(deleteMe);

		Assertions.assertEquals(true, result);
	}

	@Test
	@Order(10)
	void getEmployeesByManager()
	{
		List<Employee> result = eserv.getEmployeeByManager(1);
		System.out.println(result);
		Assertions.assertNotEquals(0,result.size());
	}


}
