package com.revature.servicetests.mockito;

import com.revature.daos.ExpenseCategoryDAO;
import com.revature.entities.ExpenseCategory;
import com.revature.services.ExpenseCategoryService;
import com.revature.services.ExpenseCategoryServiceImp;
import org.junit.jupiter.api.*;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class ExpenseCategoryServiceTest {

    @Mock
    private ExpenseCategoryDAO mockDao;

    @InjectMocks
    private ExpenseCategoryService ecserv = ExpenseCategoryServiceImp.getEserv();

    @BeforeEach
    public void setUp()
    {

        MockitoAnnotations.initMocks(this);
    }


    @Test
    @Order(1)
    void getExpenseCategoryByTitle() {
        List<ExpenseCategory> expenseCategoryArrayList = new ArrayList<ExpenseCategory>();

        ExpenseCategory e = new ExpenseCategory(1,"One","Cat.png");
        ExpenseCategory e2 = new ExpenseCategory(2,"Two","Cat.png");
        expenseCategoryArrayList.add(e);
        expenseCategoryArrayList.add(e2);

        Mockito.when(mockDao.getAllExpenseCategories()).thenReturn(expenseCategoryArrayList);
        ExpenseCategory result = ecserv.getExpenseCategoryByTitle("One");

        Assertions.assertEquals("One", result.getTitle());

        Mockito.verify(mockDao).getAllExpenseCategories();
    }
}