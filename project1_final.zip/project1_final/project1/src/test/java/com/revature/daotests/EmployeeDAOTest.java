package com.revature.daotests;

import com.revature.daos.EmployeeDAO;
import com.revature.daos.EmployeeDAOImp;
import com.revature.entities.Employee;
import org.junit.jupiter.api.*;

import java.util.List;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class EmployeeDAOTest
{

    private static EmployeeDAO edao = EmployeeDAOImp.getEdao();
    @Test
    @Order(1)
    void addEmployee()
    {
        Employee e = new Employee(6,
                "jdbcForTheWin@email.com",
                "hibernate",
                "My Name",
                "testImg.png", 7);

        Employee result = edao.addEmployee(e);

        Assertions.assertNotEquals(0, result.getEid());
    }

    @Test
    @Order(2)
    void findById()
    {
        List<Employee> slaughter = edao.findAll();
        Employee updateMe = slaughter.get(slaughter.size()-1);
        Employee result = edao.findById(updateMe.getEid());

        Assertions.assertEquals("testImg.png", result.getImage_url());
    }

    @Test
    @Order(3)
    void findAll()
    {
        List<Employee> result = edao.findAll();

        Assertions.assertNotEquals(0, result.size());
    }

    @Test
    @Order(4)
    void saveEmployee()
    {
        List<Employee> slaughter = edao.findAll();
        Employee updateMe = slaughter.get(slaughter.size()-1);
        updateMe.setEmail("MyNewEmail@email.com");
        Employee result = edao.saveEmployee(updateMe);

        Assertions.assertEquals("MyNewEmail@email.com",result.getEmail());
    }

//    @Test
//    @Order(5)
//    void deleteEmployee()
//    {
//        List<Employee> slaughter = edao.findAll();
//        Employee deleteMe = slaughter.get(slaughter.size()-1);
//
//        boolean result = edao.deleteEmployee(deleteMe);
//
//        Assertions.assertEquals(true, result);
//
//    }
}